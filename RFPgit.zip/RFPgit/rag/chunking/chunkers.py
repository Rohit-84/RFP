
from typing import List, Dict, Tuple

def chunk_text(text: str, meta: Dict, max_words: int = 550, overlap: int = 120) -> Tuple[List[str], List[Dict]]:
    if not text: return [], []
    toks = text.split()
    chunks, metas = [], []
    start = 0
    while start < len(toks):
        end = min(start + max_words, len(toks))
        chunk = " ".join(toks[start:end])
        mm = dict(meta); mm["offset"] = start
        chunks.append(chunk); metas.append(mm)
        if end == len(toks): break
        start = max(0, end - overlap)
    return chunks, metas
