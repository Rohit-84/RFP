
# Helpers for Reciprocal Rank Fusion (RRF) if you blend keyword + vector results manually.
from typing import List, Dict

def rrf_merge(keyword_hits: List[Dict], vector_hits: List[Dict], k: float = 60.0) -> List[Dict]:
    scores = {}
    def add(hits, tag):
        for rank, h in enumerate(hits, start=1):
            doc_id = h.get("id") or h.get("meta", {}).get("itemId") or str(rank)
            scores.setdefault(doc_id, {"item": h, "score": 0.0})
            scores[doc_id]["score"] += 1.0 / (k + rank)
    add(keyword_hits, "kw"); add(vector_hits, "vec")
    return [v["item"] for v in sorted(scores.values(), key=lambda x: x["score"], reverse=True)]
