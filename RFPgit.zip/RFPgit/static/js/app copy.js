// static/js/app.js
const elChat   = document.getElementById('chat');
const elSend   = document.getElementById('send');
const elPrompt = document.getElementById('prompt');
const elUserId = document.getElementById('userId');
const elK      = document.getElementById('k');
const elTemp   = document.getElementById('temp');
const elToasts = document.getElementById('toasts');

function uuid() {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, c=>{
    const r = Math.random()*16|0, v = c==='x' ? r : (r&0x3|0x8);
    return v.toString(16);
  });
}
let SESSION_ID = localStorage.getItem('chat_session_id');
if (!SESSION_ID) {
  SESSION_ID = uuid();
  localStorage.setItem('chat_session_id', SESSION_ID);
}

const saved = JSON.parse(localStorage.getItem('chat_settings') || '{}');
if(saved.userId) elUserId.value = saved.userId;
if(saved.k) elK.value = saved.k;
if(saved.temp) elTemp.value = saved.temp;

function persist(){
  localStorage.setItem('chat_settings', JSON.stringify({
    userId: elUserId.value.trim(),
    k: elK.value,
    temp: elTemp.value
  }));
}
[elUserId, elK, elTemp].forEach(el => el.addEventListener('change', persist));
[elUserId, elK, elTemp].forEach(el => el.addEventListener('input', persist));

function toast(msg){
  const t = document.createElement('div');
  t.className = 'toast';
  t.textContent = msg;
  elToasts.appendChild(t);
  setTimeout(()=> t.remove(), 3000);
}

// *** MODIFIED: Added sourceFiles argument ***
function addMsg(role, mdText, sources, fileUrl=null, sourceFiles=null){
  const row = document.createElement('div');
  row.className = 'msg ' + (role === 'user' ? 'user' : 'assistant');

  const ava = document.createElement('div');
  ava.className = 'avatar';
  ava.textContent = role === 'user' ? 'U' : 'A';

  const bubble = document.createElement('div');
  bubble.className = 'bubble';

  const txt = String(mdText || '');
  try {
    const html = marked.parse(txt || '');
    const safe = DOMPurify.sanitize(html, {ADD_ATTR: ['target','rel']});
    bubble.innerHTML = safe;
  } catch {
    bubble.textContent = txt;
  }

  // -- Append main elements --
  row.appendChild(ava);
  row.appendChild(bubble);

  // -- Add copy button for assistant messages --
  if (role === 'assistant') {
    const copyBtn = document.createElement('button');
    copyBtn.className = 'copy-btn';
    copyBtn.title = 'Copy message';
    copyBtn.setAttribute('aria-label', 'Copy message');
    copyBtn.innerHTML = `
      <svg viewBox="0 0 24 24" width="16" height="16" aria-hidden="true">
        <path fill="currentColor" d="M16 1H4a2 2 0 0 0-2 2v12h2V3h12V1zm3 4H8a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h11a2 2 0 0 0 2-2V7a2 2 0 0 0-2-2zm0 16H8V7h11v14z"/>
      </svg>`;
    copyBtn.addEventListener('click', ()=>{
      // Try to get innerText first (better for copying formatted code etc.)
      // Fallback to textContent if innerText isn't available/suitable
      const textToCopy = bubble.innerText || bubble.textContent;
      navigator.clipboard.writeText(textToCopy).then(()=> toast('Answer copied')).catch(()=> toast('Copy failed'));
    });
    // Append as a sibling to the bubble
    row.appendChild(copyBtn);
  }

  // -- Handle Download Button --
  if (fileUrl) {
    const downloadBtn = document.createElement('a');
    downloadBtn.href = fileUrl;
    const filename = fileUrl.split('/').pop();
    downloadBtn.download = filename || "download";
    downloadBtn.textContent = `⬇️ Download ${filename}`;
    downloadBtn.className = "dl-btn";

    // Append download button logically within the bubble content
    // Try appending after the last paragraph, or just at the end
    const paragraphs = bubble.querySelectorAll('p');
    const targetElement = paragraphs.length > 0 ? paragraphs[paragraphs.length - 1] : bubble;
    targetElement.appendChild(document.createElement("br")); // Add space before button
    targetElement.appendChild(downloadBtn);
  }

  // -- Handle RAG Sources --
  if (sources && Array.isArray(sources) && sources.length){
    const meta = document.createElement('div');
    meta.className = 'meta';
    meta.textContent = 'Sources:'; // RAG sources label
    const s = document.createElement('div');
    s.className = 'sources'; // Container for RAG source chips
    sources.forEach((src) => {
      const chip = document.createElement('div');
      chip.className = 'source'; // Individual RAG source chip
      const a = document.createElement('a');
      // Make RAG sources clickable only if they have a valid URL
      if (src.url && (src.url.startsWith('http://') || src.url.startsWith('https://'))) {
        a.href = src.url;
        a.target = '_blank';
        a.rel = 'noopener noreferrer';
        a.textContent = `[${src.rank}] ${src.file_name || 'source'}`;
      } else {
        // If no valid URL, display text but don't make it a link
        chip.textContent = `[${src.rank}] ${src.file_name || 'source'}`; // Use chip directly for non-links
        s.appendChild(chip); // Append chip directly
        return; // Skip appending 'a' element
      }
      chip.appendChild(a);
      s.appendChild(chip);
    });
    bubble.appendChild(meta);
    bubble.appendChild(s);
  }

  // -- *** NEW: Handle Pre-Cleanup Source Files *** --
  if (sourceFiles && Array.isArray(sourceFiles) && sourceFiles.length) {
    const fileMeta = document.createElement('div');
    fileMeta.className = 'meta'; // Reuse meta style for consistency
    fileMeta.textContent = 'Source Files Used:'; // Label for this list
    fileMeta.style.marginTop = '10px'; // Add some space above this section

    const fileListContainer = document.createElement('div');
    fileListContainer.className = 'sources'; // Reuse sources container style

    sourceFiles.forEach((fileName) => {
      const fileChip = document.createElement('div');
      fileChip.className = 'source'; // Reuse source chip style
      fileChip.textContent = fileName; // Display just the filename
      // These are not links, just informational text
      fileListContainer.appendChild(fileChip);
    });

    bubble.appendChild(fileMeta);
    bubble.appendChild(fileListContainer);
  }
  // -- *** END NEW BLOCK *** --


  elChat.appendChild(row);
  elChat.scrollTop = elChat.scrollHeight; // Scroll to bottom
}

// --- (Keep typing indicator functions: showTyping, hideTyping) ---
let typingEl = null;
function showTyping(){
  if(typingEl) return;
  typingEl = document.createElement('div');
  typingEl.className = 'msg assistant';
  const avatar = document.createElement('div');
  avatar.className = 'avatar';
  avatar.textContent = 'A';
  const bubble = document.createElement('div');
  bubble.className = 'bubble typing-bubble';
  bubble.innerHTML = `<span class="typing-label">Typing</span><span class="typing-dots"><span class="dot"></span><span class="dot"></span><span class="dot"></span></span>`;
  typingEl.appendChild(avatar);
  typingEl.appendChild(bubble);
  elChat.appendChild(typingEl);
  elChat.scrollTop = elChat.scrollHeight;
}
function hideTyping(){ if (!typingEl) return; typingEl.remove(); typingEl = null; }

function setLoading(loading){
  if(loading){
    elSend.disabled = true;
    elPrompt.disabled = true;
    showTyping();
  } else {
    elSend.disabled = false;
    elPrompt.disabled = false;
    elPrompt.focus();
    hideTyping();
  }
}

// *** MODIFIED: Pass data.source_files to addMsg ***
async function ask(){
  const q = elPrompt.value.trim();
  if(!q) return;
  addMsg('user', q);
  elPrompt.value = '';
  setLoading(true);

  try{
    const body = {
      message: q,
      session_id: SESSION_ID,
      user_id: elUserId.value.trim() || undefined,
      // Removed k and temperature - assuming backend handles defaults or they aren't needed for this endpoint
    };

    const res = await fetch('/chat', { // Ensure this endpoint matches your backend route
      method:'POST',
      headers:{ 'Content-Type':'application/json' },
      body: JSON.stringify(body)
    });

    if(!res.ok){
      let errorText = await res.text();
      try { // Try parsing as JSON for more structured error
          const errorJson = JSON.parse(errorText);
          errorText = errorJson.detail || errorJson.error || errorText;
      } catch {}
      throw new Error(`HTTP ${res.status}: ${errorText}`);
    }

    const data = await res.json();
    if (data.error){ throw new Error(data.error); }

    // Pass the new source_files array (if present) to addMsg
    addMsg(
        'assistant',
        data.answer || '(no answer)',
        data.sources || [], // RAG sources
        data.file_url || null, // Download URL
        data.source_files || null // NEW: Pre-cleanup source files
    );

    // Update session ID if backend sends a new one (optional, depends on backend logic)
    if (data.session_id) {
        SESSION_ID = data.session_id;
        localStorage.setItem('chat_session_id', SESSION_ID);
    }

  } catch (err){
    addMsg('assistant', `⚠️ Error: ${err.message}`, []);
    toast(err.message);
  } finally{
    setLoading(false);
    // persist(); // Persist settings - might not be needed after sending
  }
}


// --- (Keep event listeners and modal logic the same) ---
function updateSendState(){
  elSend.disabled = !elPrompt.value.trim();
}
elPrompt.addEventListener('input', updateSendState);
updateSendState();
elSend.addEventListener('click', ask);
elPrompt.addEventListener('keydown', (e)=>{
  if(e.key === 'Enter' && !e.shiftKey){
    e.preventDefault();
    ask();
  }
});

// Initial greeting adjusted to match backend/masterprompt
addMsg('assistant', 'Hello! I can help you with general questions or assist in creating a business presentation or document.', []);


// --- Modal Logic (Unchanged) ---
const elOpenCreate = document.getElementById('openCreate');
const elCreate = document.getElementById('createModal');
const elCloseCreate = document.getElementById('closeCreate');
const elCType = document.getElementById('cType');
const elCTitle = document.getElementById('cTitle');
const elCRef = document.getElementById('cRef');
const elCBody = document.getElementById('cBody');
const elDoCreate = document.getElementById('doCreate');

function showCreate(){ elCreate && elCreate.classList.remove('hidden'); }
function hideCreate(){ elCreate && elCreate.classList.add('hidden'); }

if (elOpenCreate) elOpenCreate.addEventListener('click', showCreate);
if (elCloseCreate) elCloseCreate.addEventListener('click', hideCreate);
if (elCreate) elCreate.addEventListener('click', (e)=> {
  if (e.target.classList && e.target.classList.contains('modal-backdrop')) hideCreate();
});

if (elDoCreate) elDoCreate.addEventListener('click', async ()=>{
  const type = (elCType.value || 'pdf').toLowerCase();
  const title = (elCTitle.value || '').trim();
  const ref = (elCRef.value || '').trim();
  const body = (elCBody.value || '').trim();
  if (!title && !ref){
    toast('Please provide a Title or a reference PPT.'); return;
  }
  let cmd;
  // --- Simplified command generation for modal ---
  if (ref) { // If reference PPT is given
      cmd = `Revise presentation ${ref}. Instructions: ${body || 'apply standard updates'}`;
  } else { // If creating from scratch using title/body
      cmd = `Create a ${type === 'ppt' ? 'PowerPoint presentation' : 'PDF document'} titled "${title}". Content details: ${body || 'standard content'}`;
  }
  // --- End simplified command generation ---

  hideCreate();
  elPrompt.value = cmd; // Put command in prompt box
  updateSendState();
  await ask(); // Trigger the ask function
});